MuSimA | Synthetic hospital experiment

Both examples ran through MuSimA Multimodal Input. Upload minimal.json and
one of the sketch ZIPs at https://abacsim.abacresearch.org/ to try the workflow.
Use the fitted-config.json files in Standard Input to reuse the exact fitted
parameters. The same seed is included in both inputs.

Only the staff distribution changed. The flat run used a Uniform fit. The
peaked run used a Normal fit. Each output ZIP includes the generated policy,
access decisions, expected-vs-observed plots, and sketch comparisons. Each
access-log CSV contains 1,000 sampled rows with 200 permits and 800 denies.
