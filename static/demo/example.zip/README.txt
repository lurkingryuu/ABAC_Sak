MuSimA tutorial examples

Hand-drawn run: upload minimal.json and peaked/peaked-input.zip in Multimodal Input.
The ZIP contains the project's original hand drawings. The fitted configuration
records the settings MuSimA extracted in this particular run.

Uniform baseline: use flat/fitted-config.json in Standard Input. It uses the same
settings and seed as the hand-drawn run, with only the SA_1 distribution changed
to Uniform. Each output ZIP includes the policy, access decisions and distribution
attestations. Each CSV contains 1,000 sampled rows with 200 permits and 800 denies.
